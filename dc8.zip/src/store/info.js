import defaultType from './type'
const type = defaultType.info
const module = {
  state: {
    login: false
  },
  mutations: {
    [type.FETCH_OK] ({commit}) {

    }
  },
  actions: {
  },
  getters: {
  }
}

export default module

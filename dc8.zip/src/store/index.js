import image from './image'

const modules = {
  image
}

export {
  modules
}

<template>
  <div>
    <mt-field label="网址" placeholder="网址"></mt-field>
  </div>
</template>
<script>
export default {
  created () {
    this.$store.dispatch('login', {url: 'http://www.yidianzixun.com/article/0JK4ax7K'})
  }
}
</script>
<style>
</style>

<template>
  <div>
    <div>
      <mt-field label="网址" placeholder="网址" v-model="url"></mt-field>
    </div>
    <div style="margin-top:10px;">
      <mt-button type="primary" size="large" @click="getImage()">Get</mt-button>
    </div>
    <div class="list-pic">
      <dl>
        <dd v-for="image in getImages">
          <a :href="image" target="_blank">
            <img :src="image"/>
          </a>
        </dd>
      </dl>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  data () {
    return {
      url: 'https://mbd.baidu.com/newspage/data/landingsuper?context=%7B%22nid%22%3A%22news_5676700277441487669%22%7D&n_type=0&p_from=1'
    }
  },
  computed: {
    ...mapGetters({
      getImages: 'getImages'
    })
  },
  methods: {
    getImage () {
      this.$store.dispatch('getImage', {url: this.url})
    }
  }
}
</script>
<style>
/* 列表 */
.list-pic{float:left;margin-bottom:12px;clear:both}
.list-pic dd{width:242px;height:212px;margin:12px 38px 0 0;float:left;display:inline}
.list-pic dd a{color:#666;height:192px;border-bottom:4px solid #fff;line-height:30px;display:block;overflow:hidden}
.list-pic dd a:hover{color:#390;border-bottom:4px solid #333;text-decoration:none}
.list-pic dd img{width:240px;height:160px;border:1px solid #EEE}
.list-pic dd i{width:13px;height:13px;background:url(http://img.lanrentuku.com/img/images/a.png) no-repeat -177px -40px;float:right;margin-top:-26px}
.list-pic .lb728x90_1{width:728px;height:90px;margin:12px 0 24px}
</style>

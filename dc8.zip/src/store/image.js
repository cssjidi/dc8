import defaultType from './type'
import fetch from './fetch'

const type = defaultType.image
const module = {
  state: {
    images: []
  },
  mutations: {
    [type.FETCH_OK] (state, payload) {
      state.images = payload.images
    },

    [type.FETCH_ERROR] ({commit, state}, payload) {

    }
  },
  actions: {
    getImage ({ commit }, {url}) {
      fetch({
        url: '/api/post',
        method: 'post',
        data: {
          url
        },
        successAction: (data) => {
          commit(type.FETCH_OK, data)
        },
        errorAction: (err) => {
          commit(type.FETCH_ERROR, err)
        }
      })
    }
  },
  getters: {
    getImages: (state) => state.images
  }
}

export default module

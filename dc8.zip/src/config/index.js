const devServer = 'http://localhost:8080'

export const API_ROOT = devServer
